function [c,ceq] = equation(m)
c = [5-m(1) m(1)-20 5-m(2) m(2)-20 5-m(3) m(3)-20 -10-m(4) m(4)-10];
ceq=[];